package com.example.v_men.sub2dicoding;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class DetailActivity extends AppCompatActivity {

    ImageView imgPhoto;
    TextView tvName, tvRemarks, tvDescription;


    public final static int EXTRA_PHOTO = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);



        Intent detailIntent = getIntent();

        final String name = detailIntent.getExtras().getString("name");
        final String remarks = detailIntent.getExtras().getString("remarks");
        final String deskripsi = detailIntent.getExtras().getString("description");
        final String photo = detailIntent.getExtras().getString("photo");


        tvName = findViewById(R.id.tv_item_name);
        imgPhoto = findViewById(R.id.img_item_photo);
        tvRemarks = findViewById(R.id.tv_item_remarks);
        tvDescription = findViewById(R.id.tv_item_description);


        tvName.setText(name);
        tvRemarks.setText(remarks);
        tvDescription.setText(deskripsi);
        imgPhoto.setImageURI(Uri.parse(photo));


        Glide.with(DetailActivity.this)
                .load(photo)
                .apply(new RequestOptions().override(150, 220))
                .into(imgPhoto);

    }
}
