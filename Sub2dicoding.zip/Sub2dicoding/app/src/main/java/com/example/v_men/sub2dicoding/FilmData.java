package com.example.v_men.sub2dicoding;

import java.util.ArrayList;


public class FilmData {
    public static String[][] data = new String[][]{
            {"Annabelle", "2014", "https://github.com/dennyrismanto/Foto/blob/master/p1annabelle.jpg?raw=true", "John Form has found the perfect gift for his expectant wife, Mia - a beautiful, rare vintage doll in a pure white wedding dress. But Mia's delight with Annabelle doesn't last long. On one horrific night, their home is invaded by members of a satanic cult, who violently attack the couple. Spilled blood and terror are not all they leave behind. The cultists have conjured an entity so malevolent that nothing they did will compare to the sinister conduit to the damned that is now... Annabelle."},
            {"The Conjuring", "2013", "https://github.com/dennyrismanto/Foto/blob/master/p2theconjuring.jpg?raw=true", "Paranormal investigators Ed and Lorraine Warren work to help a family terrorized by a dark presence in their farmhouse. Forced to confront a powerful entity, the Warrens find themselves caught in the most terrifying case of their lives."},
            {"Suzzanna: Buried Alive", "2018", "https://github.com/dennyrismanto/Foto/blob/master/p3bernafasdalamkubur.jpg?raw=true", "Satria's employees intend to rob his house when he is out of the country but their robbery turns into murder when they find Suzzanna in the house as they bury her body in the backyard."},
            {"The Nun", "2018", "https://github.com/dennyrismanto/Foto/blob/master/p4thenun.jpg?raw=true", "When a young nun at a cloistered abbey in Romania takes her own life, a priest with a haunted past and a novitiate on the threshold of her final vows are sent by the Vatican to investigate. Together they uncover the order’s unholy secret. Risking not only their lives but their faith and their very souls, they confront a malevolent force in the form of the same demonic nun that first terrorized audiences in “The Conjuring 2” as the abbey becomes a horrific battleground between the living and the damned."},
            {"Insidious", "2010", "https://github.com/dennyrismanto/Foto/blob/master/p5insidious.jpg?raw=true", "A family discovers that dark spirits have invaded their home after their son inexplicably falls into an endless sleep. When they reach out to a professional for help, they learn things are a lot more personal than they thought."},
            {"Halloween", "2018", "https://github.com/dennyrismanto/Foto/blob/master/p6halloween.jpg?raw=true", "Laurie Strode comes to her final confrontation with Michael Myers, the masked figure who has haunted her since she narrowly escaped his killing spree on Halloween night four decades ago."},
            {"Munafik", "2016", "https://github.com/dennyrismanto/Foto/blob/master/p7munafik.jpg?raw=true", "Adam is a Muslim medical practitioner who is unable to accept the fact that his wife is no longer in this world. When he agrees to treat a woman named Maria, strange and unsettling things start to happen."},
            {"Suster Keramas", "2009", "https://github.com/dennyrismanto/Foto/blob/master/p8susterkeramas.jpg?raw=true", "Michiko, a Japanese tourist comes to Indonesia to search for his brother who works as a nurse. There she meets three people who assist in her search. After while, they all begin to become victims of a haunting."},
            {"Jelangkung", "2001", "https://github.com/dennyrismanto/Foto/blob/master/p9jelangkung.jpg?raw=true", "Four young people start investigating urban legends in Jakarta. Not satisfied with their findings, they head for a more challenging phenomenon situated at Angkerbatu, West Java. One of them brings a ouija board-type toy called \"Jelangkung\" to call spirits which changes their life upon returning to Jakarta."},
            {"Train To Busan", "2016", "https://github.com/dennyrismanto/Foto/blob/master/p10traintobusan.jpg?raw=true", "Martial law is declared when a mysterious viral outbreak pushes Korea into a state of emergency. Those on an express train to Busan, a city that has successfully fended off the viral outbreak, must fight for their own survival."},

    };


    public static ArrayList<Film> getListData() {
        Film film = null;
        ArrayList<Film> list = new ArrayList<>();
        for (String[] aData : data) {
            film = new Film();
            film.setName(aData[0]);
            film.setRemarks(aData[1]);
            film.setPhoto(aData[2]);
            film.setDescription(aData[3]);

            list.add(film);
        }

        return list;
    }
}